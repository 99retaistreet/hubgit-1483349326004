<?php 
$db_username = 'RS'; 
$db_password = 'orbisindia'; 
$db_name = 'rs'; 
$db_host = 'retail'; 
$db = new mysqli($db_host, $db_username, $db_password,$db_name);
 ?>